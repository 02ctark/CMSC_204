



import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * 
 * This test the Manager class
 * @author Chris Tark
 *
 */
class CourseDBManagerTestChrisTark {
	
	private CourseDBManagerInterface m;

	@BeforeEach
	void setUp() throws Exception {
		
		m = new CourseDBManager();
	}

	@AfterEach
	void tearDown() throws Exception {
		
		m = null;
	}

	@Test
	void testAdd() {
		
		try {
			
			m.add("CMSC100",12345,4,"my house","   Thai Gary");
			m.add("CMSC010",56354,2,"joe's house","   Gary Thai");
			m.add("CMSC001",12745,3,"CS43950","   mark");
			m.add("CMSC0101",43534,4,"QQ4353","   cars");
			
		} catch (Exception e) {
		
		fail("no exception");
		}
	}

	
	@Test
	void testGet() {
		
		m.add("CMSC100",12345,4,"my house","   Thai Gary");
		m.add("CMSC010",56354,2,"joe's house","   Gary Thai");
		m.add("CMSC001",12745,3,"CS43950","   mark");
		m.add("CMSC0101",43534,4,"QQ4353","   cars");
		
		try {
			assertEquals(m.get(12345).toString(), "\nCourse:CMSC100 CRN:12345 Credits:4 Instructor:Thai Gary Room:my house");
			assertEquals(m.get(56354).toString(), "\nCourse:CMSC010 CRN:56354 Credits:2 Instructor:Gary Thai Room:joe's house");
			assertEquals(m.get(12745).toString(), "\nCourse:CMSC001 CRN:12745 Credits:3 Instructor:mark Room:CS43950");
			assertEquals(m.get(43534).toString(), "\nCourse:CMSC0101 CRN:43534 Credits:4 Instructor:cars Room:QQ4353");
			
			
		} catch(Exception e) {
			
			fail("no exception");
			
		}
	}
	
	@Test
	void testShowAll() {
		
		m.add("CMSC100",12345,4,"my house","   Thai Gary");
		m.add("CMSC010",56354,2,"joe's house","   Gary Thai");
		m.add("CMSC001",12745,3,"CS43950","   mark");
		m.add("CMSC0101",43534,4,"QQ4353","   cars");
		
		ArrayList<String> list = m.showAll();
		
		try {
			
			assertEquals(list.get(0), "\nCourse:CMSC100 CRN:12345 Credits:4 Instructor:Thai Gary Room:my house");
			assertEquals(list.get(3), "\nCourse:CMSC010 CRN:56354 Credits:2 Instructor:Gary Thai Room:joe's house");
			assertEquals(list.get(1), "\nCourse:CMSC001 CRN:12745 Credits:3 Instructor:mark Room:CS43950");
			assertEquals(list.get(2), "\nCourse:CMSC0101 CRN:43534 Credits:4 Instructor:cars Room:QQ4353");
			
			
		} catch(Exception e) {
			
			fail("no exception");
		}
		
	}
	
	@Test
	void testReadFile() {
		
		File file = new File("courses.txt");
		
		try {
			
			m.readFile(file);
			
		} catch (Exception e) {
			
			fail("no need for exception");
		}
		
		assertEquals(m.get(20484).toString(),"\nCourse:CMSC110 CRN:20484 Credits:3 Instructor:Madhvi A. Shah Room:HT300");
		assertEquals(m.get(21560).toString(),"\nCourse:CMSC110 CRN:21560 Credits:3 Instructor:Behzad Maghami Room:SC450");
		assertEquals(m.get(21560).toString(),"\nCourse:CMSC110 CRN:21560 Credits:3 Instructor:Behzad Maghami Room:SC450");
		
		
		try {
			
			m.get(12345);
		}
		catch (Exception e) {
			assertTrue("This should have caused an Exception.", true);
		}
		
	}
	
	
	
}