
/**
 * Course Data Base Element is the initial class holding course id, crn, credits, room, and instructor
 * @author Christopher Tark
 *
 */
public class CourseDBElement{
	
	//data fields
	private String IDCourse;
	private int CRN;
	private int credit;
	private String roomNumber;
	private String instructor;
	
	/**
	 * Default constructor, data fields in placed in order with no value
	 */
	CourseDBElement(){
		
		
	}
	
	/**
	 * Constructor, with variables
	 * @param IDCourse
	 * @param CRN
	 * @param credit
	 * @param roomNumber
	 * @param instructor
	 */
	CourseDBElement(String IDCourse, int CRN, int credit, String roomNumber, String instructor){
		
		this.IDCourse = IDCourse;
		this.CRN = CRN;
		this.credit = credit;
		this.roomNumber = roomNumber;
		this.instructor = instructor;
		
	}
	
	/**
	 * Create hash code 
	 * CRN - the hashcode
	 * @return 
	 */
	public int hashCode() {
		
		//orginally CRN is an int, using String.valueOf converts to string. 
		//Then hashCode() plugs in with the value of the string making a hashCode of type int
		//s[0]*31^(n-1) + s[1]*31^(n-2) + ... + s[n-1]
		String crnNumber = Integer.toString(CRN);
		return (crnNumber).hashCode();
		
	}
	
	
	//accessors and mutators
	
	/**
	 * Set course id
	 * @param IDCourse - users input id course
	 */
	public void setIDCourse(String IDCourse) {
		
		this.IDCourse = IDCourse;
	}
	
	/**
	 * Set CRN number for the specific class
	 * @param CRN - users input crn
	 */
	public void setCRN(int CRN) {
		
		this.CRN = CRN;
	}
	
	/**
	 * Set amount of credits a student can obtain from completeting the class
	 * @param credit - users input credit hour
	 */
	public void setCredit(int credit) {
		
		this.credit = credit;
	}
	/**
	 * Set where the class will be held
	 * @param roomNumber - users input room number
	 */
	public void setRoomNumber(String roomNumber) {
		
		this.roomNumber = roomNumber;
	}
	
	/**
	 * Set the professor's name
	 * @param instructor - users input teachers name
	 */
	public void setInstructor(String instructor) {
		
		this.instructor = instructor;
	}
	
	/**
	 * Get id course
	 * @return id course
	 */
	public String getIDCourse() {
		
		return this.IDCourse;
	}

	/**
	 * Get CRN number
	 * @return CRN number
	 */
	public int getCRN() {
		
		return this.CRN;
	}
	
	/**
	 * Get credit hours
	 * @return credit
	 */
	public int getCredit() {
		
		return this.credit;
	}
	
	/**
	 * Get room number
	 * @return room number
	 */
	public String getRoomNumber() {
		
		return this.roomNumber;
	}
	
	/**
	 * Get instructor' name
	 * @return name of instructor
	 */
	public String getInstructor() {
		
		return this.instructor;
	}
	
	/**
	 * Display all the information from the course
	 */
	public String toString() {
		
		return "\nCourse:"+ IDCourse + " CRN:" + CRN + " Credits:" + credit +  " Instructor:" + instructor + " Room:" + roomNumber ;
		//display: id CRN credit room instructor
	}


}
