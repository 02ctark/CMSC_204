

import java.util.ArrayList;
import java.util.LinkedList;
import java.io.*;
import java.util.Scanner;


/**
 * CourseDBManager, class can read file or enter data by hand, add new elements, 
 * get elements with specific crn, and show all elements in an array
 * @author Tark
 *
 */


/*
 * Allows user to read courses from a file or to enter the data by hand.  
 * It uses an Alert to print out the database elements.
 * The input is read from a file or read from the text fields and is added to the data structure 
 * through the add method.
 * The add method uses the CDS add method
 */
public class CourseDBManager implements CourseDBManagerInterface{

	//data field
	private CourseDBStructure CDS;
	
	/**
	 * Default constructor that initializes a class with size of type CourseDBStructure
	 * @param size
	 */
	CourseDBManager(){
		//size is final, 10
		CDS = new CourseDBStructure(15);
		
	}
	
	
	/**
	 * Create and add an entry using CourseDBStructure's add method.
	 */
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		
		CourseDBElement temp = new CourseDBElement(id.trim(), crn, credits, roomNum.trim(), instructor.trim());
		
		CDS.add(temp);
		
	}
	
	
	/**
	 * Get an entry using CourseDBStructure's get method.
	 * @throws IOException 
	 */
	public CourseDBElement get(int crn) {

		
		try {
			
			return CDS.get(crn);
			
		} catch (IOException e) {
			
			e.getMessage();
			
		}

		
		return null;

	}
	
	
	/**
	 * Read a given file of courses and add them to the DB.
	 * @param input file to be read
	 */
	public void readFile(File input) throws FileNotFoundException{
		
		FileWriter f;
		
		try {			
			
			f = new FileWriter("/Users/chris/eclipse-workspace/Assignment 4 CMSC204/Chris_bad_entries.txt");
			
			PrintWriter pw = new PrintWriter(f);
			
			//first scanner goal is to add
			Scanner sc = new Scanner(input);
			//second scanner checks comments and invaild inputs
			Scanner s = new Scanner(input);

			

			
			//if there is a line
			while(sc.hasNextLine()) {
				
				boolean ifAdded = true;
				
				//first word
				String courseid = sc.next();
				if(courseid.startsWith("CMSC")) {
					
					//go to next word
					String crn = sc.next();
					if(isNumeric(crn) && crn.length() == 5) {
						
						//go to next word
						String credits = sc.next();
						if(isNumeric(credits) && Integer.valueOf(credits) >= 1 && Integer.valueOf(credits) <= 4 ) {
							
							//next word
							String prof = sc.next();
							//complete rest of current line
							String room = sc.nextLine();
							
							//if all critria are met add
							CDS.add(new CourseDBElement(courseid.trim(), Integer.parseInt(crn), Integer.parseInt(credits), prof.trim(), room.trim()));
							ifAdded = false;
		
						}
					}
				}
				
				//failed to add 
				if(ifAdded) {
					
					String str = s.nextLine();
					// print invaild inputs in printwriter
					if(!str.startsWith("#")) {
						
						pw.println(str);
					}
					
					sc.nextLine();
				}
				if(!ifAdded) {
					
					s.nextLine();
				}
			}
			s.close();
			sc.close();
			pw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		


	}
	
	
	/**
	 * test is string is a number
	 * @param s
	 * @return
	 */
	private static boolean isNumeric(String s) {
		
		try {
			
			int i = Integer.parseInt(s);
			
		} catch (NumberFormatException e) {
			
			return false;
		}
			
		return true;
		
	}
	
	
	
//	
//	String fields[] = line.split(" ");
//	
//	//course
//	String course = fields[0];
//	//crn
//	int crn = Integer.parseInt(fields[1]);
//	//credit
//	int credits = Integer.parseInt(fields[2]);
//	//room
//	String room = fields[3];
//	//prof
//	String prof = fields[4];
	
	//print if empty spaces
//	if(fields[0] == null && fields[0] == null && fields[0] == null && fields[3] == null && fields[4] == null) {
//		
//		
//		//check for positive crn
//		if(crn <= 1){
//			
//			// credit needs to be 1 < credits < 4
//			if(credits < 4 && credits > 1) {
//				
//				//after all critria
//				if(fields[0].startsWith("CMSC")) {
//					
//					CDS.add(new CourseDBElement(course, crn, credits, room, prof));
//					
//				}
//				
//			} else {
//				
//				pw.println(line);
//				System.out.println(line);
//				
//			}
//
//			
//		} else {
//			
//			pw.println(line);
//			System.out.println(line);
//			
//		}
//		
//	} else {
//		
//		pw.println(line);
//		System.out.println(line);
//	}
	
	
	
//	PSUEDOCODE
//	
//	public void ReadFile2(String filePath) {
//
//		
//		BufferedReader br;
//		String line = null;
//		try {
//			
//			FileWriter f = new FileWriter("/Users/chris/eclipse-workspace/Assignment 4 CMSC204/Tark_bad_entries.txt");
//			br = new BufferedReader(new FileReader(filePath));
//			
//			while((line = br.readLine()) != null) {
//				
//				//String courses[] = line.split("\t");
//				String fields[] = line.split(" ");
//
//				String courseId = fields[0];
//				if(courseId.startsWith("#")) {
//					
//					continue;
//				}
//				
//				if(courseId.startsWith("CMSC")) {
//					
//					continue;
//					
//				}else {
//					
//					f.write(courseId);
//				}
//				
//				int crn = Integer.parseInt(fields[1]);
//				int length = String.valueOf(crn).length();
//				if(length == 5 && crn > 0){
//					
//					continue;
//					
//				}else {
//					
//					f.write(crn);
//				}
//				
//				int credits = Integer.parseInt(fields[2]);
//				if(credits < 4 && credits > 1) {
//					
//					continue;
//					
//				}else {
//					
//					f.write(credits);
//				}
//			}
//			
//			f.close();
//			br.close();
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//
//		
//		
//	}
	
	
	
	/**
	 * Return an ArrayList of the courses in the order of CRN.
	 */
	public ArrayList<String> showAll(){
		
		ArrayList<String> crn = new ArrayList<>();
		
		for (LinkedList<CourseDBElement> list : CDS.hashTable) {
			
			if (list != null) {
				
				for (CourseDBElement element : list) {
					
					crn.add(element.toString());
					
				}
			}
			
		}
		
		return crn;

	}


}
