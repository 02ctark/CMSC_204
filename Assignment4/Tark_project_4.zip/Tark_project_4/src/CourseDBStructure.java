
import java.io.IOException;
import java.util.LinkedList;

/**
 * The CourseDBStructure is the backbone of CourseDBElement
 * CDS holds the linkedList, mulnipulating data to add, get, and get the size
 * @author Tark
 *
 */

//Review comments of the interface to figure out how to set the length of the hash table
public class CourseDBStructure implements CourseDBStructureInterface{
	
	private int estimatedCourses;
	//create linkedlist with generic type element named hashTable
	protected LinkedList<CourseDBElement>[] hashTable;
	//private int count;
	
	/**
	 * Constructor, one that takes in an integer that is the estimated number of courses
	 * @param estimatedCourses - estimated number of courses
	 */
	@SuppressWarnings("unchecked")
	CourseDBStructure(int estimatedCourses){
		
		this.estimatedCourses = estimatedCourses;
		//hashTable with specified size
		hashTable = new LinkedList[this.estimatedCourses];
		//count = 0;
	}
	    
	/**
	 * Testing Constructor
	 */
	CourseDBStructure(String s, int estimatedCourses){
		
		this(estimatedCourses);
	}
	
	
	/** 
	* Use the hashcode of the CourseDatabaseElement to see if it is 
	* in the hashtable.
	* 
	* If the CourseDatabaseElement does not exist in the hashtable,
	* add it to the hashtable.
	* 
	* @param element the CDE to be added
	*/
	public void add(CourseDBElement element) {
		
		boolean inHashTable = false;
		//create hashCode
		int index = Math.abs(element.hashCode() % hashTable.length);
		
		//if true hashCode is not in databaseElement
		if(hashTable[index] == null) {
			
			//initailize linkedList at hashIndex
			hashTable[index] = new LinkedList<CourseDBElement>();
			
		} else if (hashTable[index] != null) {
			
			for(int i = 0; i < hashTable[index].size();i++) {
				
				if(element.getCRN() == hashTable[index].get(i).getCRN()) {
					
					hashTable[index].set(i, element);
					inHashTable = true;
					
					
				}
			}
		}
		
		//if inHashTable = true then no add
		if(!inHashTable) {
			
			//ID course must start with CMSC
			
			
				hashTable[index].add(element);
				//count++;
			
		}
	}
	
	
	
//	private boolean startWithCMSC(CourseDBElement element) {
//		
//		boolean isValid = false;
//		String check = element.getIDCourse();
//		
//		if(check.startsWith("CMSC", 0)) {
//			
//			isValid = true;
//		}
//		
//		return isValid;
//		
//		
//	}
	
	
	/** 
	* If the CourseDatabaseElement is in the hashtable, return it
	* If not, throw an IOException
	* 
	* @param crn of the element (to be returned)
	* @throws IOException 
	*/
	public CourseDBElement get(int crn) throws IOException{
		
//		CourseDBElement e = new CourseDBElement();
//		e.setCRN(crn);
//		int index = Math.abs(e.hashCode() % hashTable.length);
	    
		//iterate through hashTable
	    for (LinkedList<CourseDBElement> linkedList : hashTable) {
	    	//if there is elements
	    	if(linkedList != null) {
	    		//iterate through at specific linkedList
		    	for(CourseDBElement element : linkedList ) {
		    		
		    	    if(crn == element.getCRN()) {
		    	    	   	    	
		    	    		return element;
	
		    	    }
		    	}	
	    	}
	    }
	    
	    //After going through array (hashTable) and linkedList at each element of array if crn is not found then throw exeception
	    throw new IOException("There is no such "+ crn);
	}
	
//	private CourseDBElement getEnd(CourseDBElement cde) {
//		//iterate through hashTable
//		for (LinkedList<CourseDBElement> linkedList : hashTable) {
//			//if there is elements
//			if(linkedList != null) {
//				//iterate through at specific linkedList
//				for(CourseDBElement element : linkedList ) {
//	    		
//					if(linkedList.getLast() != null) {
//						
//						return linkedList.getLast();
//					}
//	    		
//	    	    }
//	    	}	
//    	}
//		return null;
//	}
	
	/**
	* Returns the size of the ConcordanceDataStructure (number of indexes in the array)
	*/
	public int getTableSize() {
		
		return estimatedCourses;
	}
	
	
}
