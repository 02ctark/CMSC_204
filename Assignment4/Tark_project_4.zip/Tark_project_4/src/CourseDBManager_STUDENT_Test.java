

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This class tests CourseDBManager, which implements CourseDBManagerInterface.
 * @author Catherine Allen
 */
public class CourseDBManager_STUDENT_Test {
	private CourseDBManagerInterface dataMgr;
	
	/**
	 * Creates 1 CourseDBManager object.
	 */
	@Before
	public void setUp() {
		dataMgr = new CourseDBManager();
	}

	/**
	 * Sets dataMgr to null.
	 */
	@After
	public void tearDown() {
		dataMgr = null;
	}

	/**
	 * Tests the add method.
	 */
	@Test
	public void testAdd() {
		try {
			dataMgr.add("CMSC204",12345,4,"Distance-Learning","   Carly Bonet");
			dataMgr.add("BIOL150",54321,4,"BB101","Mit E. Banks");
			dataMgr.add("SPAN102",12345,3,"FL456","Lashawna Taylor");
		}
		catch (Exception e) {
			fail("This should not have caused an Exception.");
		}
	}
	
	/**
	 * Tests the get method.
	 */
	@Test
	public void testGet() {
		dataMgr.add("CMSC204",12345,4,"Distance-Learning   ","   Carly Bonet");
		dataMgr.add("BIOL150",54321,4,"BB101","Mit E. Banks"); //Assume extra, inner whitespace isn't included.
		dataMgr.add("CMSC207",54321,4,"Distance-Learning","Linh Le");
		
		try {
			assertEquals(dataMgr.get(12345).toString(),"\nCourse:CMSC204 CRN:12345 Credits:4 Instructor:Carly Bonet Room:Distance-Learning");
			assertEquals(dataMgr.get(54321).toString(),"\nCourse:CMSC207 CRN:54321 Credits:4 Instructor:Linh Le Room:Distance-Learning");
		}
		catch (Exception e) {
			fail("This should not have caused an Exception.");
		}
	}
	
	/**
	 * Test the showAll method.
	 */
	@Test
	public void testShowAll() {
		dataMgr.add("CMSC204",12345,4,"Distance-Learning   ","   Carly Bonet");
		dataMgr.add("BIOL150",54321,4,"BB101","Mit E. Banks");
		dataMgr.add("CMSC207",54321,4,"Distance-Learning","Linh Le");
		dataMgr.add("SPAN102",12345,3,"FL456","Lashawna Taylor");
		
		ArrayList<String> courseList = dataMgr.showAll();
		
		try {
			assertEquals(courseList.get(0),"\nCourse:SPAN102 CRN:12345 Credits:3 Instructor:Lashawna Taylor Room:FL456");
			assertEquals(courseList.get(1),"\nCourse:CMSC207 CRN:54321 Credits:4 Instructor:Linh Le Room:Distance-Learning");
		}
		catch (Exception e) {
			fail("This should not have caused an Exception.");
		}
		
		try {
			courseList.get(2);
		}
		catch (Exception e) {
			assertTrue("This should have caused an Exception.", true);
		}
	}
	
	/**
	 * Tests the readFile method
	 */
	@Test
	public void testReadFile() {
		File file = new File("courses.txt");
		
		try {
			dataMgr.readFile(file);
		}
		catch (Exception e) {
			fail("This should not have caused an Exception.");
		}
		
		assertEquals(dataMgr.get(21556).toString(),"\nCourse:CMSC100 CRN:21556 Credits:2 Instructor:Janet E. Joy Room:Distance-Learning");
		assertEquals(dataMgr.get(22974).toString(),"\nCourse:CMSC100 CRN:22974 Credits:2 Instructor:Janet E. Joy Room:Distance-Learning");
		assertEquals(dataMgr.get(21560).toString(),"\nCourse:CMSC110 CRN:21560 Credits:3 Instructor:Behzad Maghami Room:SC450");
	
		try {
			dataMgr.get(12345);
		}
		catch (Exception e) {
			assertTrue("This should have caused an Exception.", true);
		}
	}
}
