import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;

public class BinaryFile {
	
	public static void main(String[] args) {
		
		//Random rand = new Random(25000);
		
//		FileOutputStream fOut;
//		FileOutputStream fOut2;
		DataOutputStream dataOut;
		DataInputStream dataIn;
		try {		
//			fOut = new FileOutputStream("Binary.txt");
//			ObjectOutputStream Oout = new ObjectOutputStream(fOut);
//			fOut2 = new FileOutputStream("ASCII.txt");
//			ObjectOutputStream Out2 = new ObjectOutputStream(fOut2);
			
			
			
			//write
			dataOut = new DataOutputStream(new FileOutputStream("Binary.dat"));
			//read
			dataIn = new DataInputStream(new FileInputStream("Binary.dat"));
			PrintWriter p = new PrintWriter("ASCII.txt");
			
			for (int i = 0; i <= 25000; i++) {
				
				p.println(randNumber());
				dataOut.writeInt(randNumber());
				System.out.println(dataIn.readInt());
			}
			
			p.close();
			dataIn.close();
			dataOut.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			
			e.getMessage();
		}

		
	}
	
	// return random number between 1000 and 9999
	public static int randNumber() {
		
		return (int) (Math.random() * (9999 - 1000)) + 1000;
	}

}


