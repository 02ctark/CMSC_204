

/**
 * Data Structure
 * 
 * 	Create a class Road that can represent the edges of a Graph of Towns.  
 * The class must implement Comparable.  The class stores references to the two vertices(Town endpoints), 
 * the distance between vertices, and a name, and the traditional methods (constructors, getters/setters, 
 * toString, etc.), and a compareTo, which compares two Road objects. Since this is an undirected graph, an 
 * edge from A to B is equal to an edge from B to A. This is the class header:
 * public class Road implements Comparable<Road>
 * @author Tark
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class TownGraphManager implements TownGraphManagerInterface {

	
	//data field
	Graph graph;
	
	TownGraphManager(){
		
		graph = new Graph();
		
	}
	/**
	 * Adds a road with 2 towns and a road name
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @param roadName name of road
	 * @return true if the road was added successfully
	 */
	public boolean addRoad(String town1, String town2, int weight, String roadName) {
		
		Town t1 = getTown(town1);
		Town t2 = getTown(town2);
		
		boolean result = true;
		
		if(graph.containsEdge(t1, t2) || graph.containsEdge(t2, t1)) {
			
			result = false;
		}
		
		if((town1 != null) && (town2 != null) && (result)) {
			
			graph.addEdge(t1, t2, weight, roadName);
		}
		
		return result;
	}
	
	/**
	 * Returns the name of the road that both towns are connected through
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return name of road if town 1 and town2 are in the same road, returns null if not
	 */
	public String getRoad(String town1, String town2) {
		
		Town t1 = getTown(town1);
		Town t2 = getTown(town2);
		
		return graph.getEdge(t1, t2).getName();
	}
	
	/**
	 * Adds a town to the graph
	 * @param v the town's name  (lastname, firstname)
	 * @return true if the town was successfully added, false if not
	 */
	public boolean addTown(String v) {
		
		Town newTown = new Town(v);

		return graph.addVertex(newTown);
	}
	
	/**
	 * Gets a town with a given name
	 * @param name the town's name 
	 * @return the Town specified by the name, or null if town does not exist
	 */
	public Town getTown(String name) {
		
		Town desiredTown = null;
		
		for(Town t : graph.vertexSet()) {
			
			if(t.getName().equals(name)) {
				
				desiredTown = t;
			}
		}
		
		return desiredTown;
	}
	
	/**
	 * Determines if a town is already in the graph
	 * @param v the town's name 
	 * @return true if the town is in the graph, false if not
	 */
	public boolean containsTown(String v) {
		
		boolean result = false;
		
		for(Town curTown : graph.vertexSet()) {
			
			if(curTown.getName().equals(v)) {
			
				result = true;
			}
		}
		
		return result;
	}
	
	/**
	 * Determines if a road is in the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return true if the road is in the graph, false if not
	 */
	public boolean containsRoadConnection(String town1, String town2) {
		
		Town t1 = getTown(town1);
		Town t2 = getTown(town2);
		
		return graph.containsEdge(t1, t2);
	}
	
	/**
	 * Creates an arraylist of all road titles in sorted order by road name
	 * @return an arraylist of all road titles in sorted order by road name
	 */
	public ArrayList<String> allRoads() {
		
		ArrayList<String> list = new ArrayList<>();
		
		for(Road curRoad : graph.edgeSet()) {
			
			list.add(curRoad.getName());
		}
		
		//sort in alphebetical order
		Collections.sort(list);
		
		return list;
		
	}
	
	/**
	 * Deletes a road from the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @param roadName the road name
	 * @return true if the road was successfully deleted, false if not
	 */
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		
		Town t1 = getTown(town1);
		Town t2 = getTown(town2);
		
		graph.removeEdge(t1, t2, 0, road);
		
		return true;
	}
	
	/**
	 * Deletes a town from the graph
	 * @param v name of town (lastname, firstname)
	 * @return true if the town was successfully deleted, false if not
	 */
	public boolean deleteTown(String v) {
		
		Town t1 = getTown(v);
		
		return graph.removeVertex(t1);
		
		
		
	}

	/**
	 * Creates an arraylist of all towns in alphabetical order (last name, first name)
	 * @return an arraylist of all towns in alphabetical order (last name, first name)
	 */
	public ArrayList<String> allTowns() {
		
		ArrayList<String> list = new ArrayList<>();
		
		for(Town curTown : graph.vertexSet()) {
			
			list.add(curTown.getName());
		}
		
		Collections.sort(list);
		
		return list;
	}
	
	/**
	 * Returns the shortest path from town 1 to town 2
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return an Arraylist of roads connecting the two towns together, null if the
	 * towns have no path to connect them.
	 */
	public ArrayList<String> getPath(String town1, String town2) {
		
		
		return graph.shortestPath(getTown(town1), getTown(town2));
		
	}
	
	
	public void populateTownGraph(File file) throws FileNotFoundException, IOException {
		
		
		Scanner s = new Scanner(file);
		
		while(s.hasNextLine()) {

			String line = s.nextLine();
			
			String[] towntotown = line.split(";");
			String[] roadinfo = towntotown[0].split(",");
				
					
			addTown(towntotown[1]);
			addTown(towntotown[2]);

			addRoad(towntotown[1], towntotown[2], Integer.parseInt(roadinfo[1]), roadinfo[0]);
			
			
		}
		
		s.close();
	}

}
