
/**
 * Test Road Class
 * @author chris
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Road_Student_Test {
	
	Road r, r2, r3, r4;
	Town t1, t2, t3;

	@BeforeEach
	void setUp() throws Exception {
		t1 = new Town("t1");
		t2 = new Town("t2");
		t3 = new Town("t3");
		r = new Road(t1, t2, 5, "wow");
		r2 = new Road(t2, t3, "coe");

	}

	
	@AfterEach
	void tearDown() throws Exception {
		
		r = r2 =null;
		t1 = null;
		t2 = null;
		t3 = null;

	}

	@Test
	void testContains() {
		
		assertEquals(true, r.contains(t1));
		assertEquals(false, r.contains(t3));
		assertEquals(true, r2.contains(t2));
		assertEquals(true, r2.contains(t2));
		
	}
	@Test
	void testToString() {
		
		assertEquals("t1 via wow to t2 5 mi", r.toString());
		assertEquals("t2 via coe to t3 1 mi", r2.toString());
		
	}
	@Test
	void testGetName() {
		
		assertEquals("wow", r.getName());
		assertNotEquals("coe", r.getName());
		assertEquals("coe", r2.getName());
		assertNotEquals("wow", r2.getName());
		
	}
	@Test
	void testGetDestination() {
		
		assertEquals(t2, r.getDestination());
		assertEquals(t3, r2.getDestination());
		assertNotEquals(t1, r.getDestination());
		assertNotEquals(t1, r2.getDestination());
	}
	@Test
	void testGetSource() {
		
		assertEquals(t1, r.getSource());
		assertEquals(t2, r2.getSource());
		assertNotEquals(t2, r.getSource());
		assertNotEquals(t3, r2.getSource());
	}
	@Test
	void testCompareTo() {
		
		assertEquals(20, r.compareTo(r2));
		assertEquals(-20, r2.compareTo(r));
	}
	@Test
	void testGetWeight() {
		
		
		assertEquals(5, r.getWeight());
		assertEquals(1, r2.getWeight());
		assertNotEquals(1, r.getWeight());
		assertNotEquals(435, r2.getWeight());
	}
	@Test
	void testEquals() {
		
		assertEquals(false, r.equals(r2));
		assertEquals(false, r2.equals(r));
	}

}
