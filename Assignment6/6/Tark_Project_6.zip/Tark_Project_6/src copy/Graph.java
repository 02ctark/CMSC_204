
/**
 * Graph implemets the graphInterface. Town - vector, Road - edge. 
 * Need to decide how to store the graph, use an adjacent matrix or adjacent list
 * @author chris
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Graph implements GraphInterface<Town, Road> {
		
	//data fields
	Set<Town> towns;
	Set<Road> roads;
	
	//dijkstra
	Town[] townsArray;
	int[] shortestDistances;
	Town[] parents;
	

	Graph() {
	
		towns = new HashSet<>();
		roads = new HashSet<>();
		
		townsArray = new Town[100];
		shortestDistances = new int[100];
		parents = new Town[100];
	}
	
    /**
     * Returns an edge connecting source vertex to target vertex if such
     * vertices and such edge exist in this graph. Otherwise returns
     * null. If any of the specified vertices is null
     * returns null
     *
     * In undirected graphs, the returned edge may have its source and target
     * vertices in the opposite order.
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     *
     * @return an edge connecting source vertex to target vertex.
     */
    public Road getEdge(Town sourceVertex, Town destinationVertex) {
    	
    	
    	for(Road theRoad : roads) {
    		
    		if(theRoad.contains(sourceVertex) && theRoad.contains(destinationVertex)) {
    			
    			return theRoad;
    		}
    	}
    	
    	//if the specified towns do not exist then there is no existing edge; therefore, returning null
    	return null;
    }
    
    /**
     * Creates a new edge in this graph, going from the source vertex to the
     * target vertex, and returns the created edge. 
     * 
     * The source and target vertices must already be contained in this
     * graph. If they are not found in graph IllegalArgumentException is
     * thrown.
     *
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     * @param weight weight of the edge
     * @param description description for edge
     *
     * @return The newly created edge if added to the graph, otherwise null.
     *
     * @throws IllegalArgumentException if source or target vertices are not
     * found in the graph.
     * @throws NullPointerException if any of the specified vertices is null.
     */
    public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) throws IllegalArgumentException, NullPointerException {
    	
    	//create newRoad, Road
    	Road newRoad = null;
    	
    	//if input of towns are null then throw exception
    	if(sourceVertex == null || destinationVertex == null) {
    		
    		throw new NullPointerException("The vertices are null");
    	}
    	
    	//if there is a source and target node, if not thow exception
    	if(containsVertex(sourceVertex) && containsVertex(destinationVertex)) {
    		
    		//make sure the weight is postive, else print negative number
        	if(weight > 0) {
        		
        		//create new edge and add to set
            	newRoad = new Road(sourceVertex, destinationVertex, weight, description);
            	roads.add(newRoad);
        	
        	} else {
        		
        		System.out.println(weight + "is negative");
        	}
    	} else {
    		
    		throw new IllegalArgumentException("One or more specified vertices were not found");
    	}
    	
    	
		return newRoad;
	}

    /**
     * Adds the specified vertex to this graph if not already present. More
     * formally, adds the specified vertex, v, to this graph if
     * this graph contains no vertex u such that
     * u.equals(v). If this graph already contains such vertex, the call
     * leaves this graph unchanged and returns false. In combination
     * with the restriction on constructors, this ensures that graphs never
     * contain duplicate vertices.
     *
     * @param v vertex to be added to this graph.
     *
     * @return true if this graph did not already contain the specified
     * vertex.
     *
     * @throws NullPointerException if the specified vertex is null.
     */
    public boolean addVertex(Town v) {
    	
    	boolean result = false;
    	
    	//not null then add
    	if(v != null) {
    		
    		towns.add(v);
    		result = true;
    	
    	}
    	
		return result;
	}

    /**
     * Returns true if and only if this graph contains an edge going
     * from the source vertex to the target vertex. In undirected graphs the
     * same result is obtained when source and target are inverted. If any of
     * the specified vertices does not exist in the graph, or if is
     * null, returns false.
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     *
     * @return true if this graph contains the specified edge.
     */
    public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		
    	boolean containsRoad = true; 
    	
    	//iterate through all the roads 
    	for(Road edge : roads) {
    		
    		//use contain as boolean
    		if(edge.contains(destinationVertex) && edge.contains(sourceVertex)) {
    			
    			return containsRoad;
    		}
    	}
    	
    	return !containsRoad;
    }

    /**
     * Returns true if this graph contains the specified vertex. More
     * formally, returns true if and only if this graph contains a
     * vertex u such that u.equals(v). If the
     * specified vertex is null returns false.
     *
     * @param v vertex whose presence in this graph is to be tested.
     *
     * @return true if this graph contains the specified vertex.
     */
    public boolean containsVertex(Town v) {
    	
		return towns.contains(v);
	}

    /**
     * Returns a set of the edges contained in this graph. The set is backed by
     * the graph, so changes to the graph are reflected in the set. If the graph
     * is modified while an iteration over the set is in progress, the results
     * of the iteration are undefined.
     *
     *
     * @return a set of the edges contained in this graph.
     */
    public Set<Road> edgeSet() {
    	
    	Set<Road> temp = new HashSet<>();
    	
    	//add all the roads into a set<road>
    	for(Road road : roads) {
    		
    		temp.add(road);
    		
    	}
    	
		return temp;
	}

    /**
     * Returns a set of all edges touching the specified vertex (also
     * referred to as adjacent vertices). If no edges are
     * touching the specified vertex returns an empty set.
     *
     * @param vertex the vertex for which a set of touching edges is to be
     * returned.
     *
     * @return a set of all edges touching the specified vertex.
     *
     * @throws IllegalArgumentException if vertex is not found in the graph.
     * @throws NullPointerException if vertex is null.
     */
    public Set<Road> edgesOf(Town vertex) {
		
    	Set<Road> touching = new HashSet<>();
    	
    	//add road if contains
    	for(Road road : roads) {
    		
    		if(road.contains(vertex)){
    			
    			touching.add(road);
    		}
    	}
    	
    	return touching;
	}


    /**
     * Removes an edge going from source vertex to target vertex, if such
     * vertices and such edge exist in this graph. 
     * 
     * If weight >- 1 it must be checked
     * If description != null, it must be checked 
     * 
     * Returns the edge if removed
     * or null otherwise.
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     * @param weight weight of the edge
     * @param description description of the edge
     *
     * @return The removed edge, or null if no edge removed.
     */
    public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
    	
    	Road remove = null;
    	
    	//find the exact road to remove
    	for(Road edge : roads) {
    		
    		if(edge.contains(destinationVertex) && edge.contains(sourceVertex) && edge.getWeight() == weight && edge.getName().equals(description)) {
	
    	    		roads.remove(edge);
    	    		remove = edge;
    	    		break;
    			
    		}
    		
    	}

    	
    	
		return remove;
	}


    /**
     * Removes the specified vertex from this graph including all its touching
     * edges if present. More formally, if the graph contains a vertex 
     * u such that u.equals(v), the call removes all edges
     * that touch u and then removes u itself. If no
     * such u is found, the call leaves the graph unchanged.
     * Returns true if the graph contained the specified vertex. (The
     * graph will not contain the specified vertex once the call returns).
     *
     * If the specified vertex is null returns false.
     *
     * @param v vertex to be removed from this graph, if present.
     *
     * @return true if the graph contained the specified vertex;
     * false otherwise.
     */
    public boolean removeVertex(Town v) {
    	
    	boolean result = false;
    	Set<Road> touching = edgesOf(v);
    	
    	//if there is town remove
    	if(v != null) {
    		
    		towns.remove(v);
    		result = true;
    		
    		//loop to find the exact Town
    		for(Road road : touching) {
    			
    			removeEdge(road.getSource(), road.getDestination(), road.getWeight(), road.getName());
    		}
    	}
    	
		return result;
    	
    	
    }

    /**
     * Returns a set of the vertices contained in this graph. The set is backed
     * by the graph, so changes to the graph are reflected in the set. If the
     * graph is modified while an iteration over the set is in progress, the
     * results of the iteration are undefined.
     *
     *
     * @return a set view of the vertices contained in this graph.
     */
    public Set<Town> vertexSet() {
    	
    	Set<Town> temp = new HashSet<>();
    	
    	//add all towns to a set
    	for(Town t : towns) {
    		
    		temp.add(t);
    	}
    	
    	return temp;
	}
    
    
    /**
     * Find the shortest path from the sourceVertex to the destinationVertex
     * call the dijkstraShortestPath with the sourceVertex
     * @param sourceVertex starting vertex
     * @param destinationVertex ending vertex
     * @return An arraylist of Strings that describe the path from sourceVertex
     * to destinationVertex
     * They will be in the format: startVertex "via" Edge "to" endVertex weight
	 * As an example: if finding path from Vertex_1 to Vertex_10, the ArrayList<String>
	 * would be in the following format(this is a hypothetical solution):
	 * Vertex_1 via Edge_2 to Vertex_3 4 (first string in ArrayList)
	 * Vertex_3 via Edge_5 to Vertex_8 2 (second string in ArrayList)
	 * Vertex_8 via Edge_9 to Vertex_10 2 (third string in ArrayList)
     */   
    public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		
    	/*
    	 * There are lots of comments to show the debugging process.
    	 */
    	
    	//for(Town t : vertexSet()) {
    		
    	//	System.out.println(t);
    	//}
    	dijkstraShortestPath(sourceVertex);
    	//System.out.println(Arrays.toString(townsArray));
    	ArrayList<String> shortestPathList = new ArrayList<>();
    	
    	//desiredTOwnIndex holds the index of sourceVertex in the translated array
    	int sourceIndex = 0;
    	int destinationIndex = 0;
    	
        for(int i = 0; i < townsArray.length; i++) {
        	
        	//System.out.println(townsArray[i]);
        	//System.out.println(sourceVertex.compareTo(townsArray[i]));
        	if(sourceVertex.compareTo(townsArray[i]) == 0) {
        		
        		sourceIndex = i;
        		break;
        	} else {
        		
        		sourceIndex = -1;
        		
        	}
        	
        }
        
        //System.out.println(sourceIndex);
        for(int i = 0; i < townsArray.length; i++) {
    		
    		if(destinationVertex.equals(townsArray[i])){
    			
    			destinationIndex = i;
    			break;
    		} else {
    			destinationIndex = -1;
    		}
    	}
        
        //System.out.println(destinationIndex);
        
        Town endTown = destinationVertex;
        
        //System.out.println(Arrays.toString(parents));
        
        while(!sourceVertex.equals(endTown)) {
        	//System.out.println(endTown);
        	//System.out.println(destinationIndex);	
        	//System.out.println(endTown.getName());
        	for(int i = 0; i < townsArray.length; i++) {
        		
        		if(endTown.equals(townsArray[i])){
        			
        			destinationIndex = i;
        			break;
        		} else {
        			destinationIndex = -1;
        		}
        	}
        	//System.out.println(destinationIndex);
        	
        	int endIndex = destinationIndex;
        	
        	Road getRoad = getEdge(endTown, parents[destinationIndex]);
        	String input = parents[destinationIndex] + " via " + getRoad.getName() + " to " + endTown.getName() + " " + getRoad.getWeight() + " mi";
        	shortestPathList.add(0, input);
        	//System.out.println("dfsgsd");
        	endTown = parents[endIndex];
        	
        }
        
        //System.out.println("dsf");
        
		return shortestPathList;
	}
    
    /**
     * Dijkstra's Shortest Path Method.  Internal structures are built which
     * hold the ability to retrieve the path, shortest distance from the
     * sourceVertex to all the other vertices in the graph, etc.
     * @param sourceVertex the vertex to find shortest path from
     * 
     */
    public void dijkstraShortestPath(Town sourceVertex) {
    	
    	//desiredTOwnIndex holds the index of sourceVertex in the translated array
    	int desiredTownIndex = 0;
		int adjacencyMatrix[][] = new int[towns.size()][towns.size()];
		
		//convert towns type set to townsArray type array
		element(townsArray);
		
		//System.out.println(Arrays.toString(townsArray));
		
		//create matrix
		for(int i = 0; i < towns.size(); i++) {
			
			for(int j = 0; j < towns.size(); j++) {
				
				if(getEdge(townsArray[i], townsArray[j]) != null) {
					
					adjacencyMatrix[i][j] = adjacencyMatrix[j][i] = getEdge(townsArray[i], townsArray[j]).getWeight();
					
				} else {
					
					adjacencyMatrix[i][j] = adjacencyMatrix[j][i] = 0;
				}
			}
		}

		
		//nVertices holds the max number of size to iterate
		int nVertices = adjacencyMatrix[0].length;
		
		//boolean array for verify if added with size of matrix
		boolean[] checked = new boolean[nVertices];
		
		//iterate through shortestDistance and assign max and assure nothing is added
        for (int vertexIndex = 0; vertexIndex < nVertices; vertexIndex++) {
        	
			shortestDistances[vertexIndex] = Integer.MAX_VALUE;
			
			checked[vertexIndex] = false;
			
		}
        
        //find sourceVertex index in townsArray
        for(int i = 0; i < nVertices; i++) {
        	
        	if(townsArray[i].equals(sourceVertex)) {
        		
        		desiredTownIndex = i;
        	}
        	
        }
        
        //System.out.println(desiredTownIndex);
        //Set sourceVertex to the start
        shortestDistances[desiredTownIndex] = 0;
        //sourceVertex has no parent
        parents[desiredTownIndex] = null; // meaning no parent 
        
        // iterate through matrix
        for (int i = 1; i < nVertices; i++) {
        	
            int nearestVertex = -1;
            int shortestDistance = Integer.MAX_VALUE;
            
            //if not boolean is false meaning unadded and distance is < current distance 
            for (int vertexIndex = 0; vertexIndex < nVertices; vertexIndex++) {
            	
                
            	if (!checked[vertexIndex] && shortestDistances[vertexIndex] < shortestDistance) {
            		
                    nearestVertex = vertexIndex;
                    shortestDistance = shortestDistances[vertexIndex];
                }
            }
            
            checked[nearestVertex] = true;
            
            // assigning parents and the distance
            for (int vertexIndex = 0; vertexIndex < nVertices; vertexIndex++) {
            	
            	int edgeDistance = adjacencyMatrix[nearestVertex][vertexIndex];
                
            	if (edgeDistance > 0 && ((shortestDistance + edgeDistance) < shortestDistances[vertexIndex])) {
            	   
            		parents[vertexIndex] = townsArray[nearestVertex];
            		shortestDistances[vertexIndex] = shortestDistance + edgeDistance;
            		
            	}
            }    
        }
        
	}
    
    /**
     * return towns set into an array
     * array is able to select exact element
     * @param array
     */
    public void element(Town[] array) {
    	
    	int i = 0;
    	
    	for(Town town : towns) {
    		
    		//System.out.println(town);
    		//System.out.println(i);
    		array[i++] = town;
    		
    	}
    	
    	//System.out.println(array.toString());
    }
    
    
    

    
    
}
