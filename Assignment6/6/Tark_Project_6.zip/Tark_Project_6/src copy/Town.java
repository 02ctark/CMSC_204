
/**
 * Represents an town as a node of a graph. 
 * The Town class holds the name of the town and a list of adjacent towns, 
 * and other fields as desired, and the traditional methods (constructors, getters/setters, toString, etc.). 
 * It will implement the Comparable interface These are the minimum methods that are needed. 
 * Please feel free to add as many methods as you need.
 * @author chris
 *
 */

public class Town extends Object implements Comparable<Town>{

	
	//data fields
	String name;
	
	/**
	 * Constructor - Requires town's name
	 * @param name - insert name of new town
	 */
	Town(String name){
		
		this.name = name;
		
	}
	
	/**
	 * Copy constructor
	 * @param templateTown - an instance of Town
	 */
	Town(Town templateTown){
		
		this.name = templateTown.getName();
	}
	
	/**
	 * Retruns the town's name
	 * @return town's name
	 */
	public String getName(){
		
		return name;
	}
	
	/**
	 * Compare to method
	 * @param o - a town being compared
	 * @return 0 if names are equal, a positive or negative number if the names are not equal
	 */
	public int compareTo(Town o) {
		
		return this.getName().compareTo(o.getName());
		
		
	}
	
	/**
	 * TO string method
	 * @Override toString in class
	 * @return the town name
	 */
	public String toString() {

		return getName();
	}
	
	/**
	 * creates hash code
	 * @return hahscode for the name of the town
	 */
	public int hashCode() {
		
		return this.name.hashCode();
	}
	
	/**
	 * compare towns
	 * @return true if the town names are equls, flase if not
	 */
	public boolean equals(Object obj) {
		
		boolean result = false;
		
		try {
			
			result = this.name.equals(((Town) obj).getName());
			
			
		} catch (NullPointerException e) {
			
			result = false;
		}
		
		return result;
	}
}
