
/**
 * Test TownGraphManager
 * @author chris
 */


import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class TownGraphManager_Student_Test {
	
	private TownGraphManagerInterface g;
	private String[] town;
	  
	@Before
	public void setUp() throws Exception {
		  g = new TownGraphManager();
		  town = new String[12];
		  
		  for (int i = 1; i < 12; i++) {
			  town[i] = "Town_" + i;
			  g.addTown(town[i]);
		  }
		  
		  g.addRoad(town[1], town[2], 2, "Road_1");
		  g.addRoad(town[1], town[3], 4, "Road_2");
		  g.addRoad(town[1], town[5], 6, "Road_3");
		  g.addRoad(town[3], town[7], 1, "Road_4");
		  g.addRoad(town[3], town[8], 2, "Road_5");
		  g.addRoad(town[4], town[8], 3, "Road_6");
		  g.addRoad(town[6], town[9], 3, "Road_7");
		  g.addRoad(town[9], town[10], 4, "Road_8");
		  g.addRoad(town[8], town[10], 2, "Road_9");
		  g.addRoad(town[5], town[10], 5, "Road_10");
		  g.addRoad(town[10], town[11], 3, "Road_11");
		  g.addRoad(town[2], town[11], 6, "Road_12");
		 
	}

	@After
	public void tearDown() throws Exception {
		g = null;
	}

	@Test
	public void testAddRoad() {
		
		ArrayList<String> roads = g.allRoads();
		//System.out.println(roads.toString());
		assertEquals("Road_1", roads.get(0));
		assertEquals("Road_3", roads.get(5));
		assertEquals("Road_4", roads.get(6));
		assertEquals("Road_5", roads.get(7));
		g.addRoad(town[4], town[11], 1,"Road_13");
		roads = g.allRoads();
		assertEquals("Road_1", roads.get(0));
		assertEquals("Road_10", roads.get(1));
		assertEquals("Road_11", roads.get(2));
		assertEquals("Road_12", roads.get(3));
		assertEquals("Road_13", roads.get(4));
		
	}

	@Test
	public void testGetRoad() {
		
		assertEquals("Road_8", g.getRoad(town[9], town[10]));
		assertEquals("Road_4", g.getRoad(town[3], town[7]));
		assertEquals("Road_1", g.getRoad(town[1], town[2]));
		assertEquals("Road_2", g.getRoad(town[1], town[3]));
	}

	@Test
	public void testAddTown() {
		
		assertEquals(false, g.containsTown("Town_12"));
		g.addTown("Town_12");
		assertEquals(true, g.containsTown("Town_12"));
		assertEquals(true, g.containsTown("Town_4"));
		assertEquals(false, g.containsTown("Town_0"));
	}
	
	

	@Test
	public void testAllRoads() {
		
		ArrayList<String> roads = g.allRoads();
		//System.out.println(roads.toString());
		assertEquals("Road_1", roads.get(0));
		assertEquals("Road_11", roads.get(2));
		assertEquals("Road_2", roads.get(4));
		assertEquals("Road_3", roads.get(5));
		assertEquals("Road_9", roads.get(11));
	}

	
	@Test
	public void testAllTowns() {
		
		ArrayList<String> roads = g.allTowns();
		//System.out.println(roads.toString());
		assertEquals("Town_1", roads.get(0));
		assertEquals("Town_10", roads.get(1));
		assertEquals("Town_11", roads.get(2));
		assertEquals("Town_7", roads.get(8));
		assertEquals("Town_9", roads.get(10));
	}

	
	//working on
	@Test
	public void testGetPath() {
		
		ArrayList<String> path = g.getPath(town[1],town[11]);
		  assertNotNull(path);
		  assertTrue(path.size() > 0);
		  assertEquals("Town_1 via Road_1 to Town_2 2 mi",path.get(0).trim());
		  assertEquals("Town_2 via Road_12 to Town_11 6 mi",path.get(1).trim());

	}
	
	
}