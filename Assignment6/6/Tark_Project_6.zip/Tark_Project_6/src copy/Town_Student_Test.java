
/**
 * Test Town Class
 * @author chris
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Town_Student_Test {

	Town t1, t2, t3, t4, t5;
	
	@BeforeEach
	void setUp() throws Exception {
		
		t1 = new Town("t1");
		t2 = new Town("t2");
		t3 = new Town("t3");
		t4 = new Town("t4");
		t5 = new Town("t5");
	}

	@AfterEach
	void tearDown() throws Exception {
		
		t1=t2=t3= t4= t5 = null;
	}

	@Test
	void testGetName() {
		
		assertEquals("t1", t1.getName());
		assertEquals("t2", t2.getName());
		assertEquals("t3", t3.getName());
		assertEquals("t4", t4.getName());
		assertEquals("t5", t5.getName());
	}
	
	@Test
	void testCompareTo() {
		
		assertEquals(0, t1.compareTo(t1));
		assertEquals(1, t2.compareTo(t1));
		assertEquals(3, t5.compareTo(t2));
		assertEquals(-1, t2.compareTo(t3));
		
	}
	@Test
	void testToString() {
		
		assertEquals("t1", t1.getName());
		assertEquals("t2", t2.getName());
		assertEquals("t3", t3.getName());
		assertEquals("t4", t4.getName());
		assertEquals("t5", t5.getName());
	}
	@Test
	void testHashCode() {
		
		assertNotNull(t1.hashCode());
		assertNotNull(t2.hashCode());
		assertNotNull(t3.hashCode());
		assertNotNull(t4.hashCode());
		assertNotNull(t5.hashCode());
	}
	@Test
	void testEquals() {
		
		assertEquals(true, t1.equals(t1));
		assertEquals(false, t1.equals(t2));
		assertEquals(false, t1.equals(t3));
		assertEquals(false, t1.equals(t4));
		
	}


}
