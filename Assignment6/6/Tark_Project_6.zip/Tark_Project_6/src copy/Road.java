
/**
 * The class Road that can represent the edges of a Graph of Towns. 
 * The class must implement Comparable. The class stores references to the two vertices(Town endpoints), 
 * the distance between vertices, and a name, and the traditional methods (constructors, getters/setters, 
 * toString, etc.), and a compareTo, which compares two Road objects. Since this is a undirected graph, an 
 * edge from A to B is equal to an edge from B to A.
 * @author chris
 *
 */
public class Road extends Object implements Comparable<Road>{
	
	
	//data fields
	private Town source;
	private Town destination;
	private int degrees;
	private String name;
	
	
	/**
	 * Constructor
	 * @param source - one twon on the road
	 * @param destination - Another own on the road
	 * @param degrees - Weight of the edge, i.e., distance from one twon to the other
	 * @param name - name of road
	 */
	Road(Town source, Town destination, int degrees, String name) {
		
		this.source = source;
		this.destination = destination;
		this.degrees = degrees;
		this.name = name;
		
	}
	
	/**
	 * Constructor with weight preset at 1
	 * @param source - One town on the road
	 * @param destination - Another town on the road
	 * @param name - Name of the road
	 */
	Road(Town source, Town destination, String name) {
		
		this.source = source;
		this.destination = destination;
		this.degrees = 1;
		this.name = name;
	}
	
	/**
	 * Returns true only if the edge contains the given town
	 * @param town - a vertex of the graph
	 * @return true only if the edge is connected to the given vertex
	 */
	public boolean contains(Town town) {
		
		boolean result = false;
		
		if(town.equals(source)) {
			
			result = true;
			
		} else if(town.equals(destination)) {
			
			result = true;
		}
		
		return result;
	}
	
	/** 
	 * To string method
	 * Vertex_1 via Edge_2 to Vertex_3 4 (first string in ArrayList)
	 * Vertex_3 via Edge_5 to Vertex_8 2 (second string in ArrayList)
	 * Vertex_8 via Edge_9 to Vertex_10 2 (third string in ArrayList)
	 */
	public String toString() {
		
		return source.getName() + " via " + name + " to " + destination.getName()+ " "+ degrees+ " mi";
	}
	
	/**
	 * Returns the road
	 * @return
	 */
	public String getName() {
		
		return this.name;
	}
	
	/**
	 * REturns the road name
	 * @return - name of the road
	 */
	public Town getDestination() {
		
		return this.destination;
	}
	
	/**
	 * Returns the second town on the road
	 * @return A town on the road
	 */
	public Town getSource() {
		
		return this.source;
	}
	
	/**
	 * Return 0 if the road names are the same, a postive or negative number if the road names are not the same.
	 */
	public int compareTo(Road o) {
		
		return this.name.compareTo(o.name);
	}
	
	/**
	 * Returns the distance of the road
	 * @return - distance of the road
	 */
	public int getWeight() {
		
		return this.degrees;
	}
	
	/**
	 * Returns true if each of the ends of the road r is the same as the ends of this road. 
	 * Remember that a road that goes from point A to point B is the same as a road that goes from point B to point A.
	 * @param r - road object to compare it to
	 */
	public boolean equals(Object r) {
		
		Road checkRoad = (Road) r;
		boolean result = false;
		
		if(destination == checkRoad.destination && source == checkRoad.source) {
			
			result = true;
			
		} else if(destination == checkRoad.source && source == checkRoad.destination) {
			
			result = true;
		}
		
		return result;
	}
	
}
