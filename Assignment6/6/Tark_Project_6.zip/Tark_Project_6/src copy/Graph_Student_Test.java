
/**
 * Test Graph
 * @author chris
 */

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Set;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Graph_Student_Test {
	
	private Graph g;
	private String[] t;

	@BeforeEach
	void setUp() throws Exception {
		
		t = new String[5];
		
		for(int i = 0; i < t.length; i++) {
			t[i] = "t" + i;
			
		}
		
		g = new Graph();
		
		g.addVertex(new Town("t1"));
		g.addVertex(new Town("t2"));
		g.addVertex(new Town("t3"));
		g.addVertex(new Town("t4"));
		g.addVertex(new Town("t5"));
		
		g.addEdge(new Town("t1"), new Town("t2"), 1, "will ave");
		g.addEdge(new Town("t1"), new Town("t3"), 2, "mark ave");
		g.addEdge(new Town("t3"), new Town("t5"), 1, "cool ave");
		g.addEdge(new Town("t2"), new Town("t5"), 1, "jill ave");
		
		
	}

	@AfterEach
	void tearDown() throws Exception {
		
		g = null;
	}
	
	@Test
	void testAddEdge() {
		
		try {
			
			g.addEdge(new Town("t1"), new Town("t2"), 1, "will ave");
			g.addEdge(new Town("t1"), new Town("t3"), 2, "mark ave");
			g.addEdge(new Town("t3"), new Town("t5"), 1, "cool ave");
			g.addEdge(new Town("t2"), new Town("t5"), 1, "jill ave");
			
		} catch (Exception e) {
			
			fail(e.getMessage());
		}

		
	}
	
	@Test
	void testAddVertex() {
		
		try {
			
			g.addVertex(new Town("t1"));
			g.addVertex(new Town("t2"));
			g.addVertex(new Town("t3"));
			g.addVertex(new Town("t4"));
			g.addVertex(new Town("t5"));
			
			
		} catch(Exception e ) {
			
			fail(e.getMessage());
		}

	}
	
	@Test
	void testContainsEdge() {
		
		assertEquals(true, g.containsEdge(new Town("t1"), new Town("t2")));
		assertEquals(true, g.containsEdge(new Town("t1"), new Town("t3")));
		assertEquals(false, g.containsEdge(new Town("t2"), new Town("t10")));
		
		assertEquals(true, g.containsEdge(new Town("t3"), new Town("t5")));
		assertEquals(true, g.containsEdge(new Town("t2"), new Town("t5")));
	}
	
	@Test
	void testContainsVertex() {
		
		assertEquals(true, g.containsVertex(new Town("t1")));
		assertEquals(true, g.containsVertex(new Town("t2")));
		assertEquals(false, g.containsVertex(new Town("t77")));
		assertEquals(true, g.containsVertex(new Town("t3")));
		assertEquals(true, g.containsVertex(new Town("t2")));
		
	}
	
	@Test
	void testEdgeSet() {
		
		ArrayList<String> list = new ArrayList<>();
		
		for(Road r : g.edgeSet()) {
			
			list.add(r.getName());
			//System.out.println(r.getName());
		}
		
		Collections.sort(list);
		//System.out.println(list.toString());
		assertEquals("cool ave", list.get(0));
		assertEquals("jill ave", list.get(1));
		assertEquals("mark ave", list.get(2));
		assertEquals("will ave", list.get(3));
	}
	
	@Test
	void testEdgeOf() {
		
		ArrayList<String> list = new ArrayList<>();
		
		for(Road r : g.edgesOf(new Town("t1"))) {
			
			list.add(r.getName());
			//System.out.println(r.getName());
		}

		Collections.sort(list);
		
		assertEquals("mark ave", list.get(0));
		assertEquals("will ave", list.get(1));
		
		
	}
	
	@Test
	void testRemoveEdge() {
		
		
		
		try {
			
			g.removeEdge(new Town("t1"), new Town("t2"), 1, "will ave");
			g.removeEdge(new Town("t1"), new Town("t3"), 2, "mark ave");
			g.removeEdge(new Town("t3"), new Town("t5"), 1, "cool ave");
			g.removeEdge(new Town("t2"), new Town("t5"), 1, "jill ave");
			
		} catch(Exception e) {
			
			fail(e.getMessage());
			
		}
	
		
	}
	
	@Test
	void testRemoveVertex() {
		
		try {
			
			g.removeVertex(new Town("t1"));
			g.removeVertex(new Town("t2"));
			g.removeVertex(new Town("t3"));
			g.removeVertex(new Town("t4"));
			
			
		} catch (Exception e) {
			
			fail(e.getMessage());
		}
	}
	
	@Test
	void testVertexSet() {
		
		String[] town = new String[5];
		int i = 0;
		for(Town t : g.vertexSet()) {
			
			town[i++] = t.getName();
			//System.out.println(t);
		}
		
		
		assertEquals("t4", town[0]);
		assertEquals("t5", town[1]);
		assertEquals("t1", town[2]);
		assertEquals("t2", town[3]);
	}
	
	@Test
	void testShortestPath() {
		
		ArrayList<String> path = g.shortestPath(new Town("t1"), new Town("t5"));
		  
		  assertTrue(path.size() > 0);
		  assertEquals("t1 via will ave to t2 1 mi",path.get(0).trim());
		  assertEquals("t2 via jill ave to t5 1 mi",path.get(1).trim());
	}
	

}
